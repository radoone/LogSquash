#!/bin/bash
# LogSquash Installer for Gemini CLI

set -e

EXTENSION_DIR="$HOME/.gemini/extensions/logsquash"
REPO_URL="https://github.com/radoone/LogSquash.git"
TEMP_DIR=$(mktemp -d)

echo "🪵 LogSquash: Installing Gemini extension..."

echo "Cloning repository to temporary directory..."
git clone --depth 1 "$REPO_URL" "$TEMP_DIR"
cd "$TEMP_DIR"

echo "Building LogSquash..."
npm install
npm run build

echo "Installing to Gemini CLI..."
# Clean existing installation if present
rm -rf "$EXTENSION_DIR"
mkdir -p "$EXTENSION_DIR/skills"

# Copy only necessary files for Gemini CLI
cp -r dist "$EXTENSION_DIR/"
cp -r node_modules "$EXTENSION_DIR/"
cp package.json "$EXTENSION_DIR/"
cp plugins/gemini/gemini-extension.json "$EXTENSION_DIR/"
cp -r plugins/gemini/skills/* "$EXTENSION_DIR/skills/"

# Clean up
cd "$HOME"
rm -rf "$TEMP_DIR"

echo "✅ LogSquash installed successfully!"
echo "Restart your Gemini CLI session to activate the new tools."
